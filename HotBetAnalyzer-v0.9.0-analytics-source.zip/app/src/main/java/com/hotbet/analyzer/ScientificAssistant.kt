package com.example.hotbetanalyzer

import java.util.Locale
import kotlin.math.*

/** Deterministic offline helper. Does not claim to be a general language model. */
object ScientificAssistant {
    private fun digits(s: String): String = s.map { c -> when(c) {
        in '۰'..'۹' -> ('0'.code + c.code - '۰'.code).toChar()
        in '٠'..'٩' -> ('0'.code + c.code - '٠'.code).toChar()
        else -> c
    }}.joinToString("")
    private fun fmt(d: Double): String = if (!d.isFinite()) "نامعتبر" else String.format(Locale.US, "%.5g", d)

    fun answer(input: String): String {
        val s = digits(input.trim()).lowercase(Locale.ROOT).replace('−','-').replace('×','*').replace('÷','/')
        if (s.isBlank()) return "سؤالت را بنویس."
        val concentration = Regex("(?:10\\s*(?:\\^|به توان)\\s*\\(?\\s*(-?\\d+)\\s*\\)?|([0-9]+(?:\\.[0-9]+)?)\\s*(?:mol/l|مولار))").find(s)
        val isPh = listOf("ph", "poh", "هیدروکسید", "غلظت", "هیدرونیوم").any { s.contains(it) }
        if (isPh && concentration != null) {
            val h = concentration.groupValues[1].takeIf { it.isNotEmpty() }?.toDoubleOrNull()?.let { 10.0.pow(it) }
                ?: concentration.groupValues[2].toDoubleOrNull()
            if (h != null && h > 0 && h <= 1) {
                val ph = -log10(h)
                val poh = 14 - ph
                return "با فرض محلول آبی رقیق در ۲۵°C و اینکه غلظت داده‌شده مربوط به +H باشد:\n[H⁺] = ${fmt(h)} mol/L\npH = −log₁₀[H⁺] = ${fmt(ph)}\npOH = 14 − pH = ${fmt(poh)}\n[OH⁻] = 10⁻¹⁴ / [H⁺] = ${fmt(1e-14/h)} mol/L\nتوجه: برای محلول‌های غلیظ یا دماهای دیگر این تقریب دقیق نیست."
            }
        }
        val mol = Regex("([0-9]+(?:\\.[0-9]+)?)\\s*(?:گرم|g)\\s*(?:از\\s*)?(آب|هیدروژن|اکسیژن|h2o|h2|o2)").find(s)
        if (mol != null && listOf("مول", "mol").any { s.contains(it) }) {
            val grams = mol.groupValues[1].toDouble()
            val kind = mol.groupValues[2]
            val mass = when(kind) { "آب", "h2o" -> 18.015; "هیدروژن", "h2" -> 2.016; else -> 31.998 }
            return "تعداد مول = جرم ÷ جرم مولی\nجرم: ${fmt(grams)} g\nجرم مولی $kind: ${fmt(mass)} g/mol\nنتیجه: ${fmt(grams / mass)} mol\nفرض: هیدروژن و اکسیژن به‌شکل مولکولی H₂ و O₂ هستند."
        }
        val definitions = listOf(
            listOf("نوروپلاستیسیتی", "انعطاف پذیری عصبی") to "نوروپلاستیسیتی یا انعطاف‌پذیری عصبی توانایی دستگاه عصبی برای تغییر قدرت اتصال‌های سیناپسی و سازمان‌دهی شبکه‌ها در اثر یادگیری، تجربه یا آسیب است.",
            listOf("ایروسل", "آئروسل") to "ایروسل مجموعه‌ای از ذرات جامد یا قطره‌های مایع معلق در یک گاز است؛ مانند مه، دود و ذرات معلق هوا.",
            listOf("آمپر", "ampere") to "آمپر (A) واحد جریان الکتریکی است. یک آمپر معادل عبور یک کولن بار الکتریکی در هر ثانیه است: I = Q/t.",
            listOf("ولت", "voltage") to "ولت (V) واحد اختلاف پتانسیل الکتریکی است؛ یک ولت برابر یک ژول انرژی بر هر کولن بار است. در رسانای اهمی: V = I×R.",
            listOf("هیدروژن") to "هیدروژن (H)، عنصر شماره ۱ جدول تناوبی، سبک‌ترین عنصر است. گاز هیدروژن معمولاً به شکل مولکول H₂ وجود دارد.",
            listOf("اکسیژن") to "اکسیژن (O)، عنصر شماره ۸ است. گاز اکسیژن معمولاً O₂ است و برای تنفس هوازی بسیاری از جانداران ضروری است.",
            listOf("آب", "h2o") to "آب با فرمول H₂O از دو اتم هیدروژن و یک اتم اکسیژن تشکیل شده و مولکولی قطبی است.",
            listOf("گاز") to "گاز حالتی از ماده است که شکل و حجم ثابتی ندارد و فضای ظرف را پر می‌کند. رفتار گاز ایده‌آل با PV = nRT تقریب زده می‌شود.",
            listOf("لگاریتم") to "لگاریتم معکوس توان‌رسانی است: اگر 10^x = a، آنگاه log₁₀(a)=x. مثال: log₁₀(100)=2.",
            listOf("ph") to "pH معیاری لگاریتمی از فعالیت یون هیدروژن است؛ در محلول رقیق pH ≈ −log₁₀[H⁺]. در ۲۵°C، pH + pOH ≈ 14."
        )
        if (s.contains("چیست") || s.contains("توضیح") || s.contains("تعریف") || s.endsWith("؟") || s.endsWith("?")) {
            definitions.firstOrNull { (keys,_) -> keys.any { s.contains(it) } }?.let { return it.second }
        }
        val calculation = s.replace(" ", "")
            .replace("log(", "log10(")
        val cleaned = calculation.removeSuffix("=").removeSuffix("؟").removeSuffix("?")
        if (cleaned.length in 1..120 && cleaned.any { it.isDigit() } && cleaned.matches(Regex("[0-9.+*/^()\\-a-z]*"))) {
            try { return "نتیجه: ${fmt(Parser(cleaned).parse())}" } catch (_: Exception) { /* not a pure expression */ }
        }
        return "در حالت آفلاین می‌توانم تعریف‌های پایه علوم، محاسبه مول و pH/pOH و عبارت‌های عددی مثل 2^3 + log10(100) را پاسخ بدهم. برای پرسش‌های باز و پیچیده، در تنظیمات دستیار نشانی امن سرویس آنلاین را وارد کن."
    }

    private class Parser(private val s: String) {
        private var p = 0
        fun parse(): Double { val v = expr(); if (p != s.length) error("trailing input"); return v }
        private fun eat(c: Char): Boolean { if (p < s.length && s[p] == c) { p++; return true }; return false }
        private fun expr(): Double { var v = term(); while (true) v = when { eat('+') -> v + term(); eat('-') -> v - term(); else -> return v } }
        private fun term(): Double { var v = power(); while (true) v = when { eat('*') -> v * power(); eat('/') -> v / power(); else -> return v } }
        private fun power(): Double { val v = unary(); return if (eat('^')) v.pow(power()) else v }
        private fun unary(): Double = when { eat('-') -> -unary(); eat('+') -> unary(); else -> atom() }
        private fun atom(): Double {
            if (eat('(')) { val n = expr(); require(eat(')')); return n }
            if (s.startsWith("log10(",p)) { p += 6; val n=expr(); require(eat(')') && n>0); return log10(n) }
            val start=p
            while (p<s.length && (s[p].isDigit() || s[p]=='.')) p++
            require(p>start)
            return s.substring(start,p).toDouble()
        }
    }
}
