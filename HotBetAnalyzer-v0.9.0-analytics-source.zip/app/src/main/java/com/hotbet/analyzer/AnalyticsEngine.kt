package com.example.hotbetanalyzer

import java.util.Locale
import kotlin.math.sqrt

/**
 * Five descriptive engines. These summarize historical observations only.
 * They do not predict an independent random next round.
 */
object AnalyticsEngine {
    data class Result(
        val report: String,
        val sampleSize: Int,
        val bins: List<Int>,
        val agreement: String
    )

    fun analyze(values: List<Double>): Result {
        val x = values.filter { it.isFinite() && it >= 1.0 && it <= 1000.0 }
        if (x.size < 10) {
            return Result(
                "برای تحلیل آماری اولیه حداقل ۱۰ ضریب معتبر لازم است؛ اکنون ${x.size} مورد داریم.\n" +
                "تا آن زمان فقط داده‌ها ثبت می‌شوند؛ هیچ حدس قابل اتکایی ارائه نمی‌شود.",
                x.size, listOf(0,0,0,0,0), "داده ناکافی"
            )
        }
        val sorted = x.sorted()
        fun q(p: Double): Double = sorted[((sorted.size - 1) * p).toInt()]
        fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)
        val mean = x.average()
        val median = if (sorted.size % 2 == 1) sorted[sorted.size/2]
            else (sorted[sorted.size/2-1] + sorted[sorted.size/2]) / 2.0
        val variance = x.sumOf { (it-mean)*(it-mean) } / x.size
        val sd = sqrt(variance)
        val bins = listOf(
            x.count { it < 1.5 },
            x.count { it >= 1.5 && it < 2.0 },
            x.count { it >= 2.0 && it < 3.0 },
            x.count { it >= 3.0 && it < 5.0 },
            x.count { it >= 5.0 }
        )
        val percentages = bins.map { 100.0 * it / x.size }
        val recent = x.takeLast(minOf(30, x.size))
        val prior = x.dropLast(recent.size).takeLast(minOf(30, x.size - recent.size))
        val recentMean = recent.average()
        val priorMean = if (prior.isEmpty()) Double.NaN else prior.average()
        val runs = x.takeLast(30).zipWithNext().count { (a,b) -> (a >= 2.0) == (b >= 2.0) }
        val lag1 = if (x.size >= 3) {
            val a=x.dropLast(1); val b=x.drop(1)
            val ma=a.average(); val mb=b.average()
            val num=a.indices.sumOf { (a[it]-ma)*(b[it]-mb) }
            val den=sqrt(a.sumOf{(it-ma)*(it-ma)}*b.sumOf{(it-mb)*(it-mb)})
            if (den == 0.0) 0.0 else num/den
        } else 0.0

        // The five engines report descriptive evidence, not a next-round forecast.
        val engine1 = "۱) توزیع: میانگین ${fmt(mean)}×، میانه ${fmt(median)}×، چارک اول ${fmt(q(.25))}× و چارک سوم ${fmt(q(.75))}×."
        val engine2 = "۲) فراوانی بازه‌ها: زیر ۱٫۵: ${bins[0]} (${fmt(percentages[0])}٪)، ۱٫۵–۲: ${bins[1]} (${fmt(percentages[1])}٪)، ۲–۳: ${bins[2]} (${fmt(percentages[2])}٪)، ۳–۵: ${bins[3]} (${fmt(percentages[3])}٪)، ۵ به بالا: ${bins[4]} (${fmt(percentages[4])}٪)."
        val engine3 = "۳) توالی: در ۳۰ مشاهده اخیر، $runs جفتِ متوالی در یک سوی آستانه ۲× بوده‌اند؛ این شمارش به‌تنهایی الگوی پیش‌بینی نیست."
        val engine4 = "۴) نوسان: انحراف معیار کل ${fmt(sd)}×؛ میانگین ۳۰ مورد اخیر ${fmt(recentMean)}×" +
            if (priorMean.isFinite()) " در برابر ${fmt(priorMean)}× در ۳۰ مورد پیش از آن." else "."
        val engine5 = "۵) وابستگی زمانی: همبستگی ساده وقفه یک ${fmt(lag1)} است؛ با نمونه محدود و داده تصادفی، این مقدار ممکن است صرفاً نویز باشد."
        val consensus = "جمع‌بندی: پنج موتور فقط وضعیت نمونه تاریخی را توصیف می‌کنند؛ هیچ توافقی بین آن‌ها به معنی احتمال بیشتر برای ضریب دور بعد نیست."
        val report = listOf(
            "نمونه معتبر: ${x.size} ضریب",
            engine1, engine2, engine3, engine4, engine5, consensus,
            "راهنمای استفاده: درصدهای بازه‌ها فراوانی گذشته‌اند، نه پیش‌بینی دور بعد. برای ارزیابی هر ادعای پیش‌بینی باید آن را روی داده‌های آینده‌نگرِ جداگانه و بدون دست‌کاری آزمایش کرد."
        ).joinToString("\n\n")
        return Result(report, x.size, bins, "توصیفی؛ بدون پیش‌بینی")
    }
}
