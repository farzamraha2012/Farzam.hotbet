package com.example.hotbetanalyzer

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Offline-first chat. Optional online route uses a user-owned HTTPS proxy, not embedded API secrets. */
class AssistantActivity : Activity() {
    private val gold = Color.rgb(226,185,92)
    private val background = Color.rgb(12,13,17)
    private val panel = Color.rgb(29,30,36)
    private lateinit var body: LinearLayout
    private lateinit var input: EditText
    private lateinit var mode: Switch
    private lateinit var threads: JSONArray
    private var current = ""
    private val prefs by lazy { getSharedPreferences("assistant_v08", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = background
        window.navigationBarColor = background
        threads = try { JSONArray(prefs.getString("threads", "[]")) } catch (_: Exception) { JSONArray() }
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18, 16, 18, 12); setBackgroundColor(this@AssistantActivity.background) }
        val bar = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        bar.addView(TextView(this).apply { text="✦ دستیار Farzam.kh"; textSize=19f; setTextColor(gold); setTypeface(null,Typeface.BOLD) }, LinearLayout.LayoutParams(0,-2,1f))
        bar.addView(action("چت‌ها") { historyDialog() })
        bar.addView(action("جدید") { newChat() })
        root.addView(bar)
        mode = Switch(this).apply { text="پاسخ آنلاین (در صورت اتصال)"; setTextColor(Color.WHITE); isChecked=prefs.getBoolean("online",false); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("online",v).apply() } }
        root.addView(mode)
        root.addView(action("تنظیم نشانی HTTPS سرویس هوش مصنوعی") { settingsDialog() })
        val scroll=ScrollView(this).apply { isFillViewport=true }
        body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,12,0,12) }
        scroll.addView(body)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val entry=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        input=EditText(this).apply { hint="سؤال علمی یا محاسبه را بنویس..."; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE); minLines=1; maxLines=4; setSingleLine(false) }
        entry.addView(input,LinearLayout.LayoutParams(0,-2,1f))
        entry.addView(action("ارسال") { send() })
        root.addView(entry)
        setContentView(root)
        if (threads.length()>0) openThread(threads.getJSONObject(threads.length()-1).optString("id")) else newChat()
    }
    private fun action(name:String, f:()->Unit)=Button(this).apply { text=name; isAllCaps=false; setTextColor(Color.BLACK); setBackgroundColor(gold); setOnClickListener { f() } }
    private fun save() { prefs.edit().putString("threads",threads.toString()).apply() }
    private fun newChat() { current=UUID.randomUUID().toString(); threads.put(JSONObject().put("id",current).put("title","گفت‌وگوی جدید").put("messages",JSONArray())); save(); render() }
    private fun thread(): JSONObject { for(i in 0 until threads.length()) if(threads.getJSONObject(i).optString("id")==current) return threads.getJSONObject(i); return threads.getJSONObject(threads.length()-1) }
    private fun add(role:String,text:String) {
        val t=thread(); val messages=t.getJSONArray("messages")
        messages.put(JSONObject().put("role",role).put("text",text))
        if(messages.length()==1) t.put("title",text.take(45))
        save(); render()
    }
    private fun render() {
        body.removeAllViews()
        val arr=thread().optJSONArray("messages") ?: JSONArray()
        if(arr.length()==0) bubble("assistant","سلام! سؤالات شیمی، فیزیک و محاسبات pH و مول را به‌صورت آفلاین بپرس. در حالت آنلاین به سرویس HTTPS خودت متصل می‌شوم.")
        for(i in 0 until arr.length()) { val m=arr.getJSONObject(i); bubble(m.optString("role"),m.optString("text")) }
    }
    private fun bubble(role:String,text:String) {
        val wrapper=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,10,14,10)
            background=GradientDrawable().apply { setColor(if(role=="user") Color.rgb(54,46,30) else panel); cornerRadius=18f } }
        wrapper.addView(TextView(this).apply { this.text=if(role=="user") "شما" else "دستیار"; textSize=12f; setTextColor(gold) })
        wrapper.addView(TextView(this).apply { this.text=text; textSize=16f; setTextColor(Color.WHITE); setTextIsSelectable(true) })
        wrapper.addView(action("کپی") { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("response",text)); Toast.makeText(this,"کپی شد",Toast.LENGTH_SHORT).show() })
        body.addView(wrapper,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=12 })
    }
    private fun send() {
        val question=input.text.toString().trim(); if(question.isEmpty()) return
        input.setText(""); val id=current; add("user",question)
        if(!mode.isChecked) { add("assistant",ScientificAssistant.answer(question)); return }
        val endpoint=prefs.getString("endpoint","").orEmpty()
        if(!endpoint.startsWith("https://")) { add("assistant","سرویس آنلاین هنوز تنظیم نشده است. پاسخ آفلاین:\n"+ScientificAssistant.answer(question)); return }
        Thread {
            val result=try {
                val conn=URL(endpoint).openConnection() as HttpURLConnection
                conn.requestMethod="POST"; conn.connectTimeout=10000; conn.readTimeout=25000; conn.doOutput=true
                conn.setRequestProperty("Content-Type","application/json; charset=utf-8")
                val payload=JSONObject().put("message",question).toString()
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val status=conn.responseCode
                if(status !in 200..299) error("HTTP $status")
                val data=conn.inputStream.bufferedReader().use { it.readText().take(100000) }
                JSONObject(data).getString("reply").take(12000)
            } catch(e:Exception) { "اتصال آنلاین برقرار نشد (${e.javaClass.simpleName}). پاسخ آفلاین:\n"+ScientificAssistant.answer(question) }
            runOnUiThread { if(current==id) add("assistant",result) else { val index=(0 until threads.length()).firstOrNull { threads.getJSONObject(it).optString("id")==id }; if(index!=null) { threads.getJSONObject(index).getJSONArray("messages").put(JSONObject().put("role","assistant").put("text",result)); save() } } }
        }.start()
    }
    private fun settingsDialog() {
        val field=EditText(this).apply { setText(prefs.getString("endpoint","")); hint="https://your-domain.example/chat"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("سرور اختصاصی دستیار").setMessage("نشانی HTTPS سرور واسط خودت را بنویس. درخواست POST با {message} ارسال می‌شود و باید پاسخ JSON با فیلد reply برگردد. کلید API را اینجا وارد نکن؛ آن باید فقط روی سرور باشد.").setView(field)
            .setPositiveButton("ذخیره") { _,_ -> val value=field.text.toString().trim(); if(value.isEmpty() || value.startsWith("https://")) prefs.edit().putString("endpoint",value).apply() else Toast.makeText(this,"فقط HTTPS مجاز است",Toast.LENGTH_LONG).show() }
            .setNegativeButton("انصراف",null).show()
    }
    private fun openThread(id:String) { current=id; render() }
    private fun historyDialog() {
        val names=(0 until threads.length()).reversed().map { i -> threads.getJSONObject(i).optString("title") }.toTypedArray()
        AlertDialog.Builder(this).setTitle("چت‌های گذشته").setItems(names) { _, which -> openThread(threads.getJSONObject(threads.length()-1-which).getString("id")) }
            .setNeutralButton("حذف گفت‌وگوی فعلی") { _,_ -> AlertDialog.Builder(this).setTitle("حذف این گفت‌وگو؟").setPositiveButton("حذف") { _,_ -> val next=JSONArray(); for(i in 0 until threads.length()) { val t=threads.getJSONObject(i); if(t.optString("id")!=current) next.put(t) }; threads=next; save(); if(threads.length()==0)newChat() else openThread(threads.getJSONObject(threads.length()-1).getString("id")) }.setNegativeButton("انصراف",null).show() }
            .setNegativeButton("بستن",null).show()
    }
}
